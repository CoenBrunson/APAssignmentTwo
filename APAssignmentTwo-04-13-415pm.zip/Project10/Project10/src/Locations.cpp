#include "Locations.h"

Location::~Location()
{
	for (int i = 0; i < (int)m_vConnected.size(); i++) {
		m_vConnected[i] = nullptr;
	}
	m_vConnected.clear();
	m_vConnected.shrink_to_fit();
}

void Location::AddNeighbor(Location* neighbor)
{
	m_vConnected.push_back(neighbor);
}

bool Location::checkInput(char string[], int commandLength)
{
	bool goodInput = true;
	int loopLength = commandLength - 1;

	for (int i = 0; i < loopLength; i++)
	{
		if (inputString[i] != string[i])
		{
			goodInput = false;
			break;
		}
	}
	return goodInput;
}

void Location::getInput()
{
	bool traveling = false;
	std::string temp;
	do
	{
		memset(inputString, 0, sizeof(inputString));
		Story::Instance()->displayNode(0);
		std::cin.getline(inputString, 100);
		if (GetWorld()->GetPlayer()->getVisited(0) == false)
		{
			if (checkInput(moveCommand, 15)) {
				getMoveInput(GetLocationIndex());
				if (GetTravelIndex() != GetLocationIndex())
					traveling = true;
			}
			else if (checkInput(invCommand, 15))
				GetWorld()->GetPlayer()->getInventory();
			else if (checkInput(lookCommand, 12)) {
				Story::Instance()->displayNode(GetStartingTextIndex());
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
			}
		}

	} while (!traveling);
	
	GetWorld()->Travel(GetTravelIndex());
}

void Location::getMoveInput(int location)
{
	Story::Instance()->displayDirections(location);
	bool needsInput = true;
	do
	{
		memset(inputString, 0, sizeof(inputString));
		std::cin.getline(inputString, 100);
		switch (location) {
		case 0:
			if (checkInput(town, 5)) {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 1:
			if (checkInput(hills, 6)) {
				needsInput = false;
				SetTravelIndex(2);
				break;
			}
			if (checkInput(forest, 7)) {
				needsInput = false;
				SetTravelIndex(3);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 2:
			if (checkInput(town, 5)) {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			if (checkInput(temple, 7)) {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 3:
			if (checkInput(town, 5)) {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			if (checkInput(temple, 7)) {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 4:
			if (checkInput(camp, 6)) {
				needsInput = false;
				SetTravelIndex(5);
				break;
			}
			if (checkInput(hills, 6)) {
				needsInput = false;
				SetTravelIndex(2);
				break;
			}
			if (checkInput(forest, 7)) {
				needsInput = false;
				SetTravelIndex(3);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 5:
			if (checkInput(temple, 7)) {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		}

	} while (needsInput);
}

void Location::displayText(int index)
{
	Story::Instance()->displayNode(index);
}

Location* Location::getNext(int index)
{
	if (index <= (int)m_vConnected.size())
		return m_vConnected[index];
	else return nullptr;
}

std::string Location::getUserInput()
{
	return std::string(); // cin for 2 strings, concat to 1, return
}

GrassLands::GrassLands(World* pWorld) : Location(pWorld)
{
	SetLocationName("Grasslands");
	SetLocationIndex(0);
	SetStartingTextIndex(22);
	SetCurrentTextIndex(GetStartingTextIndex());
}

void GrassLands::sequence()
{
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->setVisited(GetLocationIndex());
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

City::City(World* pWorld) : Location(pWorld)
{
	SetLocationName("Town");
	SetLocationIndex(1);
	SetStartingTextIndex(40);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(3);
}

void City::sequence()
{
	std::cout << GetWorld()->getObjective() << std::endl;
	switch (GetWorld()->getObjective()) {
	case 0:
		Story::Instance()->displayNode(39);
		getInput();
		GetWorld()->GetPlayer()->setVisited(1);
		GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
		GetWorld()->Travel(GetTravelIndex());
		break;
	case 1:
		Story::Instance()->displayNode(52);
		delete GetWorld();
		system("pause");
	}
}

Hills::Hills(World* pWorld) : Location(pWorld)
{
	SetLocationName("Hills");
	SetLocationIndex(2);
	SetStartingTextIndex(38);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(5);
}

void Hills::sequence()
{
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->setVisited(GetLocationIndex());
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

Woods::Woods(World* pWorld) : Location(pWorld)
{
	SetLocationName("Woods");
	SetLocationIndex(3);
	SetStartingTextIndex(29);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(7);
}

void Woods::sequence()
{
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	delete GetWorld();
	system("pause");
}

Temple::Temple(World* pWorld) : Location(pWorld)
{
	SetLocationName("Temple");
	SetLocationIndex(4);
	SetStartingTextIndex(47);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(9);
}

void Temple::sequence()
{
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->setVisited(GetLocationIndex());
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

Camp::Camp(World* pWorld) : Location(pWorld)
{
	SetLocationName("Camp");
	SetLocationIndex(5);
	SetStartingTextIndex(48);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(11);
}

void Camp::sequence()
{
	Story::Instance()->displayNode(GetStartingTextIndex());
	getInput();
	GetWorld()->setObjective(1);
	GetWorld()->GetPlayer()->setVisited(GetLocationIndex());
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

World::World()
{
	m_pPlayer = new Player();
}

World::~World()
{
	delete m_pPlayer;
	m_pPlayer = nullptr;
	for (int i = 0; i < (int)m_vLocations.size(); i++) {
		delete m_vLocations[i];
		m_vLocations[i] = nullptr;
	}
	m_vLocations.clear();
	m_vLocations.shrink_to_fit();
}

void World::Start()
{
	GenerateWorld();
	ConnectWorld();
	Travel(0);
}

void World::GenerateWorld()
{
	m_vLocations.push_back(new GrassLands(this)); // 0
	m_vLocations.push_back(new City(this)); // 1
	m_vLocations.push_back(new Hills(this)); // 2
	m_vLocations.push_back(new Woods(this)); // 3
	m_vLocations.push_back(new Temple(this)); // 4
	m_vLocations.push_back(new Camp(this)); // 5
}

void World::ConnectWorld()
{
	//grasslands connected to city
	m_vLocations[0]->AddNeighbor(m_vLocations[1]);
	//city connected to hills, woods
	m_vLocations[1]->AddNeighbor(m_vLocations[2]);
	m_vLocations[1]->AddNeighbor(m_vLocations[3]);
	//hills connected to city, temple
	m_vLocations[2]->AddNeighbor(m_vLocations[1]);
	m_vLocations[2]->AddNeighbor(m_vLocations[4]);
	//woods connected to city, temple
	m_vLocations[3]->AddNeighbor(m_vLocations[1]);
	m_vLocations[3]->AddNeighbor(m_vLocations[4]);
	//temple connected to hills, woods, camp
	m_vLocations[4]->AddNeighbor(m_vLocations[2]);
	m_vLocations[4]->AddNeighbor(m_vLocations[3]);
	m_vLocations[4]->AddNeighbor(m_vLocations[5]);
	//camp connected to temple, hills (secret tunnel?)
	m_vLocations[5]->AddNeighbor(m_vLocations[4]);
	m_vLocations[5]->AddNeighbor(m_vLocations[2]);
}

void World::Travel(int index)
{
	system("cls");
	GetPlayer()->SetLocationIndex(index);
	m_vLocations[GetPlayer()->GetLocationIndex()]->sequence();
}
