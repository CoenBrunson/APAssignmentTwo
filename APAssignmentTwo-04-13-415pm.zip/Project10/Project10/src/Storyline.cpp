#include "StoryLine.h"
Story* Story::s_pInstance;

Story::Story() {
	head = nullptr;
	tail = nullptr;
	scriptFile.open("scriptFile.txt");
	if (scriptFile.is_open()) {
		std::cout << "Script successful." << std::endl;
	}
	else
		std::cout << "Error opening script." << std::endl;
	read(5, 31);
	read(7, 41);
	read(10, 40);
	read(13, 40);
	read(16, 49);
	read(20, 33);
	read(0, 99);
	read(22, 496);
	read(39, 523);
	read(38, 68);
	read(29, 523);
	read(47, 81);
	read(48, 321);
	read(52, 284);
}

Story::~Story() // deletes all nodes in the story list
{
	StoryNode* current = head;
	StoryNode* next;

	while (current != NULL) {
		next = current->next;
		free(current);
		current = next;
	}
	head = NULL;
	scriptFile.close();
}

void Story::read(int x, int y)//**********************TODO*********************************
{
	//index = 0. open istream, for each line in text, save line to string, push string and index into add fuction. close istream
	if (scriptFile.is_open())
	{
		memset(speechString, 0, sizeof(speechString));
		GotoLine(scriptFile, x);
		for (int a = 0; a < y; a++)
		{
			scriptFile >> std::noskipws >> speechString[a];
		}

		int a_size = sizeof(speechString);
		std::string temp;
		temp = convertToString(speechString, a_size);
		add(temp, x);
	}
}

void Story::add(std::string in, int indx) // adds a node to the end of the list
{
	StoryNode* temp = new StoryNode();
	temp->index = indx;
	temp->text = in;

	if (head == NULL) {
		head = temp;
		tail = temp;
	}
	else {
		tail->next = temp;
		tail = tail->next;
	}
}

void Story::displayNode(int index) //displays the text of a node with the required index
{
	StoryNode* temp;
	temp = head;
	while (temp != NULL) {
		if (temp->index == index) {
			std::cout << temp->text << std::endl;
		}
		temp = temp->next;
	}
}

std::fstream& Story::GotoLine(std::fstream& file, unsigned int num) {
	file.seekg(std::ios::beg);
	for (int i = 0; i < num; ++i) {
		file.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	}
	return file;
}

std::string Story::convertToString(char* a, int size)
{
	int i;
	std::string s = "";
	for (i = 0; i < size; i++) {
		s = s + a[i];
	}
	return s;
}

void Story::displayDirections(int locationIndex)
{
	switch (locationIndex) {
	case 0: //grasslands
		displayNode(5);
		break;
	case 1: //town
		displayNode(7);
		break;
	case 2: //hills
		displayNode(10);
		break;
	case 3: //forest
		displayNode(14);
		break;
	case 4: //temple
		displayNode(16);
		break;
	case 5: //camp
		displayNode(20);
		break;
	}
}

