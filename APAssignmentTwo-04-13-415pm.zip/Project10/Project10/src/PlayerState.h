#pragma once
#include<vector>
#include<string>
#include<iostream>

class Player {
private:
	int m_locationIndex, m_numObjectives;
	//objectives
	bool m_visited[10];

	std::vector<std::string> weaponVec;
	std::vector<std::string> itemVec;
public:
	bool lambKilled = false;
	bool haveSword = false;
	bool savedGirl = false;
	bool killedMonster = false;
	Player();
	~Player() {}
	int GetLocationIndex() { return m_locationIndex; }
	void SetLocationIndex(int index) { m_locationIndex = index; }
	void setVisited(int locationIndex) { m_visited[locationIndex] = true; }
	bool getVisited(int locationIndex) { return m_visited[locationIndex]; };
	void getInventory();
};