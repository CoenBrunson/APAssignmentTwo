#pragma once
#include "Actor.h"

class BackGround : public Actor {
private:
public:

};

class MidGround : public Actor {
private:

public:

};

class ForeGround : public Actor {
private:

public:

};