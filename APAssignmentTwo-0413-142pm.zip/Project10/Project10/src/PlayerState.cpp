#include "PlayerState.h"

Player::Player() {
	SetLocationIndex(0);
	weaponVec.push_back(std::string("shortsword"));
}

void Player::getInventory()
{
	for (auto string : weaponVec)
	{
		std::cout << "Weapons: " << std::endl;
		std::cout << string << ", ";
	}

	if (!itemVec.empty()) {
		for (auto string : itemVec)
		{
			std::cout << "Items: " << std::endl;
			std::cout << string << ", ";
		}
	}
	else
		std::cout << "You have no useable items." << std::endl;
}
