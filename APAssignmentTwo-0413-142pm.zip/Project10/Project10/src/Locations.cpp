#include "Locations.h"

Location::~Location()
{
	for (int i = 0; i < (int)m_vConnected.size(); i++) {
		m_vConnected[i] = nullptr;
	}
	m_vConnected.clear();
	m_vConnected.shrink_to_fit();
}

void Location::AddNeighbor(Location* neighbor)
{
	m_vConnected.push_back(neighbor);
}

void Location::getInput()
{
	Story::Instance()->read(0, 99);
	Story::Instance()->displayNode(0);
	bool traveling = false;
	std::string temp;
	do
	{
		std::cin.getline(inputString, 100);
		int a_size = sizeof(inputString);
		temp = Story::Instance()->convertToString(inputString, a_size);
		std::cout << inputPtr << std::endl;
		std::cout << command << std::endl;
		if (GetWorld()->GetPlayer()->getVisited(0) == false)
		{
			if (strcmp(inputPtr, command)) {
				getMoveInput(0);
				setUserInput("");
			}
			else if (getUserInput() == "view inventory")
			{
				GetWorld()->GetPlayer()->getInventory();
				setUserInput("");
			}
			else if (getUserInput() == "look around") {
				Story::Instance()->displayNode(GetStartingTextIndex());
				setUserInput("");
			}
		}

	} while (!traveling);
	
}

void Location::getMoveInput(int location)
{
	Story::Instance()->displayDirections(location);
	bool needsInput = true;
	do
	{
		std::string temp;
		std::cin >> temp;
		setUserInput(temp);

		switch (location) {
		case 0:
			if (getUserInput() == "town") {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 1:
			if (getUserInput() == "hills"){
				needsInput = false;
				SetTravelIndex(2);
				break;
			}
			else if (getUserInput() == "forest") {				
				needsInput = false;
				SetTravelIndex(3);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 2:
			if (getUserInput() == "town") {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			else if (getUserInput() == "temple") {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 3:
			if (getUserInput() == "town") {
				needsInput = false;
				SetTravelIndex(1);
				break;
			}
			else if (getUserInput() == "temple") {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 4:
			if (getUserInput() == "camp") {
				needsInput = false;
				SetTravelIndex(5);
				break;
			}
			else if (getUserInput() == "hills") {
				needsInput = false;
				SetTravelIndex(2);
				break;
			}
			else if (getUserInput() == "forest") {
				needsInput = false;
				SetTravelIndex(3);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		case 5:
			if (getUserInput() == "temple") {
				needsInput = false;
				SetTravelIndex(4);
				break;
			}
			else {
				std::cout << "Sorry, try again." << std::endl;
				break;
			}
		}

	} while (needsInput);
}

void Location::displayText(int index)
{
	Story::Instance()->displayNode(index);
}

Location* Location::getNext(int index)
{
	if (index <= (int)m_vConnected.size())
		return m_vConnected[index];
	else return nullptr;
}

std::string Location::getUserInput()
{
	return std::string(); // cin for 2 strings, concat to 1, return
}

GrassLands::GrassLands(World* pWorld) : Location(pWorld)
{
	SetLocationName("Grasslands");
	SetLocationIndex(0);
	SetStartingTextIndex(22);
	SetCurrentTextIndex(GetStartingTextIndex());
}

void GrassLands::sequence()
{
	Story::Instance()->read(22, 496);
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
	GetWorld()->GetPlayer()->setVisited(0);
}

City::City(World* pWorld) : Location(pWorld)
{
	SetLocationName("Town");
	SetLocationIndex(1);
	SetStartingTextIndex(40);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(3);
}

void City::sequence()
{
	Story::Instance()->read(40, 504);
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
	GetWorld()->GetPlayer()->setVisited(1);
}

Hills::Hills(World* pWorld) : Location(pWorld)
{
	SetLocationName("Hills");
	SetLocationIndex(2);
	SetStartingTextIndex(39);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(5);
}

void Hills::sequence()
{
	Story::Instance()->read(39, 68);
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

Woods::Woods(World* pWorld) : Location(pWorld)
{
	SetLocationName("Woods");
	SetLocationIndex(3);
	SetStartingTextIndex(30);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(7);
}

void Woods::sequence()
{
	Story::Instance()->read(30, 523);
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

Temple::Temple(World* pWorld) : Location(pWorld)
{
	SetLocationName("Temple");
	SetLocationIndex(4);
	SetStartingTextIndex(47);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(9);
}

void Temple::sequence()
{
	Story::Instance()->read(47, 81);
	Story::Instance()->displayNode(GetStartingTextIndex()); //display location entry message
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

Camp::Camp(World* pWorld) : Location(pWorld)
{
	SetLocationName("Camp");
	SetLocationIndex(5);
	SetStartingTextIndex(48);
	SetCurrentTextIndex(GetStartingTextIndex());
	SetEndingTextIndex(11);
}

void Camp::sequence()
{
	Story::Instance()->read(48, 321);
	Story::Instance()->displayNode(GetStartingTextIndex());
	getInput();
	GetWorld()->GetPlayer()->SetLocationIndex(GetTravelIndex());
	GetWorld()->Travel(GetTravelIndex());
}

World::World()
{
	m_pPlayer = new Player();
}

World::~World()
{
	delete m_pPlayer;
	m_pPlayer = nullptr;
	for (int i = 0; i < (int)m_vLocations.size(); i++) {
		delete m_vLocations[i];
		m_vLocations[i] = nullptr;
	}
	m_vLocations.clear();
	m_vLocations.shrink_to_fit();
}

void World::Start()
{
	GenerateWorld();
	ConnectWorld();
	Travel(0);
}

void World::GenerateWorld()
{
	m_vLocations.push_back(new GrassLands(this)); // 0
	m_vLocations.push_back(new City(this)); // 1
	m_vLocations.push_back(new Hills(this)); // 2
	m_vLocations.push_back(new Woods(this)); // 3
	m_vLocations.push_back(new Temple(this)); // 4
	m_vLocations.push_back(new Camp(this)); // 5
}

void World::ConnectWorld()
{
	//grasslands connected to city
	m_vLocations[0]->AddNeighbor(m_vLocations[1]);
	//city connected to hills, woods
	m_vLocations[1]->AddNeighbor(m_vLocations[2]);
	m_vLocations[1]->AddNeighbor(m_vLocations[3]);
	//hills connected to city, temple
	m_vLocations[2]->AddNeighbor(m_vLocations[1]);
	m_vLocations[2]->AddNeighbor(m_vLocations[4]);
	//woods connected to city, temple
	m_vLocations[3]->AddNeighbor(m_vLocations[1]);
	m_vLocations[3]->AddNeighbor(m_vLocations[4]);
	//temple connected to hills, woods, camp
	m_vLocations[4]->AddNeighbor(m_vLocations[2]);
	m_vLocations[4]->AddNeighbor(m_vLocations[3]);
	m_vLocations[4]->AddNeighbor(m_vLocations[5]);
	//camp connected to temple, hills (secret tunnel?)
	m_vLocations[5]->AddNeighbor(m_vLocations[4]);
	m_vLocations[5]->AddNeighbor(m_vLocations[2]);
}

void World::Travel(int index)
{
	system("cls");
	GetPlayer()->SetLocationIndex(index);
	m_vLocations[GetPlayer()->GetLocationIndex()]->sequence();
}
